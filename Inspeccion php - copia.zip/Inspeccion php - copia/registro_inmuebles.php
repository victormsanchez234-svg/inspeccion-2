<?php
// Validamos la sesión
session_start();
if (!isset($_SESSION["cve_usuarios"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>.: Nuevo Inmueble - Protección Civil :.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="css/styles.css" rel="stylesheet" type="text/css" />
    <link href="imagenes/faviconhor.png" rel="shortcut icon" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* Estilo para que el formulario se vea como una tarjeta centrada en la página */
        .form-page-container {
            background-color: #1e293b;
            border-radius: 12px;
            border: 1px solid #334155;
            padding: 40px;
            max-width: 900px;
            margin: 20px auto; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <header class="dashboard-header">
        <h1>Registrar Nuevo Inmueble</h1>
        <div class="header-user-info">
             <span>Usuario: <?= htmlspecialchars($_SESSION["usuario"] ?? "Desconocido") ?></span>
            <a href="inmuebles.php" class="btn-salir" style="margin-left:10px; background-color: #334155;">CANCELAR Y VOLVER</a>
        </div>
    </header>

    <div class="form-page-container">
        <form action="#" method="post" enctype="multipart/form-data">
            
            <div class="form-group" style="margin-bottom: 25px;">
                <label class="form-label" style="color: #ffab00; font-weight: bold; font-size: 1.1rem;">Tipo de Inmueble / Inspección</label>
                <select class="form-control" id="tipo_inmueble" name="tipo_inmueble" onchange="toggleCamposDinamicos()" style="border-color: #ffab00; background-color: rgba(255, 171, 0, 0.1); font-size: 1.05rem;">
                    <option value="">-- Selecciona el tipo para desplegar opciones --</option>
                    <option value="residencial">Casa Habitación / Residencial</option>
                    <option value="comercial">Comercial / Empresarial</option>
                    <option value="industrial">Instalación Industrial</option>
                </select>
            </div>

            <h3 style="color: #cbd5e1; font-size: 1.2rem; border-bottom: 1px solid #334155; padding-bottom: 8px;">Datos Generales</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div class="form-group">
                    <label class="form-label">Nombre Comercial o Familia (Residencial)</label>
                    <input type="text" class="form-control" name="nombre" placeholder="Ej. Plaza Crystal o Familia Pérez">
                </div>
                <div class="form-group" id="div_giro">
                    <label class="form-label">Giro / Actividad</label>
                    <select class="form-control" name="giro">
                        <option>Comercial general</option>
                        <option>Alimentos y Bebidas</option>
                        <option>Servicios / Oficinas</option>
                        <option>Bodega / Almacenamiento</option>
                        <option>Educativo / Escuela</option>
                    </select>
                </div>
            </div>

            <div id="seccion_empresarial" style="display: none; background-color: rgba(59, 130, 246, 0.1); padding: 20px; border-radius: 8px; border: 1px solid #3b82f6; margin-bottom: 20px;">
                <h3 style="color: #3b82f6; font-size: 1.1rem; margin-top:0;">Datos Legales y Empresariales</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">RFC de la Empresa</label>
                        <input type="text" class="form-control" name="rfc" placeholder="Ej. EMP123456789">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">Representante Legal</label>
                        <input type="text" class="form-control" name="representante" placeholder="Nombre completo">
                    </div>
                </div>
            </div>

            <h3 style="color: #cbd5e1; font-size: 1.2rem; border-bottom: 1px solid #334155; padding-bottom: 8px;">Ubicación Detallada</h3>
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 20px; margin-bottom: 15px;">
                <div class="form-group">
                    <label class="form-label">Calle / Avenida</label>
                    <input type="text" class="form-control" name="calle" placeholder="Ej. Paseo Usumacinta">
                </div>
                <div class="form-group">
                    <label class="form-label">No. Exterior</label>
                    <input type="text" class="form-control" name="num_ext" placeholder="Ej. 204">
                </div>
                <div class="form-group">
                    <label class="form-label">No. Interior</label>
                    <input type="text" class="form-control" name="num_int" placeholder="Opcional">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 2fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div class="form-group">
                    <label class="form-label">Manzana (Mz)</label>
                    <input type="text" class="form-control" name="manzana" placeholder="Opcional">
                </div>
                <div class="form-group">
                    <label class="form-label">Lote (Lt)</label>
                    <input type="text" class="form-control" name="lote" placeholder="Opcional">
                </div>
                <div class="form-group">
                    <label class="form-label">Colonia / Fraccionamiento</label>
                    <input type="text" class="form-control" name="colonia" placeholder="Ej. Tabasco 2000">
                </div>
                <div class="form-group">
                    <label class="form-label">C.P.</label>
                    <input type="text" class="form-control" name="cp" placeholder="Ej. 86035">
                </div>
            </div>

            <h3 style="color: #cbd5e1; font-size: 1.2rem; border-bottom: 1px solid #334155; padding-bottom: 8px;">Propietario, Contacto y Evidencia</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div class="form-group">
                    <label class="form-label">Nombre de Propietario / Contacto</label>
                    <input type="text" class="form-control" name="propietario" placeholder="¿Quién atiende?">
                </div>
                <div class="form-group">
                    <label class="form-label">Teléfono</label>
                    <input type="text" class="form-control" name="telefono" placeholder="Ej. 993...">
                </div>
                <div class="form-group">
                    <label class="form-label">Nivel de Riesgo Previsto</label>
                    <select class="form-control" name="riesgo">
                        <option value="bajo">Bajo (Verde)</option>
                        <option value="medio">Medio (Naranja)</option>
                        <option value="alto">Alto (Rojo)</option>
                    </select>
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 30px;">
                <label class="form-label">Fotos de Fachada / Croquis (Opcional)</label>
                <div class="file-upload-area" onclick="document.getElementById('fotos-inmueble').click()" style="border: 2px dashed #3b82f6; padding: 30px; text-align: center; border-radius: 8px; cursor: pointer; background: rgba(59, 130, 246, 0.05); transition: 0.3s;">
                    <i class="fa-solid fa-camera" style="font-size: 2.5rem; color: #3b82f6; margin-bottom: 15px;"></i>
                    <p style="color: #94a3b8; margin: 0; font-size: 1.1rem;">Haz clic aquí para subir imágenes (.jpg, .png)</p>
                    <input type="file" id="fotos-inmueble" name="fotos[]" multiple accept="image/*" style="display: none;">
                </div>
            </div>

            <hr style="border: 0; border-top: 1px solid #334155; margin-bottom: 20px;">

            <div class="form-actions" style="justify-content: flex-end; gap: 15px;">
                <button type="button" class="btn-cancel" onclick="window.location.href='inmuebles.php'" style="padding: 12px 25px; font-size: 1rem;">Cancelar</button>
                <button type="submit" class="btn-save" style="padding: 12px 25px; font-size: 1rem;">Guardar Inmueble</button>
            </div>
        </form>
    </div>
</div>

<script src="scripts/registroInm_scripts.js?v=<?= time() ?>"></script>

</body>
</html>