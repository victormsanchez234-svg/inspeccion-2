<?php
// Validamos la sesión antes de enviar cualquier código HTML
session_start();

if (!isset($_SESSION["cve_usuarios"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>.: Gestión de Actas - Protección Civil :.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="css/styles.css" rel="stylesheet" type="text/css" />
    <link href="imagenes/faviconhor.png" rel="shortcut icon" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>

<div class="dashboard-container">

    <header class="dashboard-header">
        <h1>Gestión de Actas de Inspección</h1>
        <div class="header-user-info">
             <span>Usuario: <?= htmlspecialchars($_SESSION["usuario"] ?? "Desconocido") ?></span>
             <a href="dashboard.php" class="btn-salir" style="margin-left:10px; background-color: #334155;">CANCELAR Y VOLVER</a>
        </div>
    </header>

    <div class="view-tabs">
        <button class="tab-btn active">Pendientes por Cerrar</button>
        <button class="tab-btn">Actas Concluidas</button>
    </div>

    <div id="view-list">
        
        <div class="toolbar">
            <div class="search-wrapper">
                <i class="fa-solid fa-search" style="position: absolute; left: 15px; top: 13px; color: #94a3b8;"></i>
                <input type="text" class="search-input" placeholder="Buscar por número de acta, folio o contribuyente...">
            </div>
            <button onclick="alert('Aquí abriremos el formulario')" class="action-button" style="background-color: #ffab00; color: white; border:none; cursor: pointer;">
                + Nuevo Registro
            </button>
        </div>

        <div class="actas-list-container">
            
            <div class="acta-card">
                <div class="acta-info-principal">
                    <h3>
                        <i class="fa-solid fa-file-signature" style="color: #ffab00;"></i> 
                        Visita Ordinaria V.O. 11/2021
                    </h3>
                    
                    <div class="acta-grid-detalles">
                        <div class="acta-detalle-item">
                            <span>Clave (Cve)</span>
                            <p>13</p>
                        </div>
                        <div class="acta-detalle-item">
                            <span>Folio</span>
                            <p>V.O. 11/2021</p>
                        </div>
                        <div class="acta-detalle-item">
                            <span>Fecha de Creación</span>
                            <p>04/05/2022</p>
                        </div>
                        <div class="acta-detalle-item" style="grid-column: span 3;">
                            <span>Inspector Asignado</span>
                            <p>LUIS ENRIQUE SALAYA RODRIGUEZ</p>
                        </div>
                        <div class="acta-detalle-item" style="grid-column: span 3;">
                            <span>Observaciones</span>
                            <p style="color: #94a3b8; font-style: italic;">Sin observaciones registradas.</p>
                        </div>
                    </div>

                    <button class="action-button" style="background-color: transparent; border: 1px solid #ffab00; color: #ffab00; padding: 8px 15px;">
                        <i class="fa-solid fa-camera"></i> Agregar o Revisar Fotos
                    </button>
                </div>

                <div class="acta-acciones-lateral">
                    <div class="acta-status-badge status-nuevo">
                        <i class="fa-solid fa-circle-dot" style="font-size: 0.6rem; margin-right: 5px;"></i> N/A (NUEVO REGISTRO)
                    </div>
                    
                    <div style="display: flex; gap: 15px; margin-top: auto;">
                        <a href="#" style="color:#3b82f6; font-size: 1.2rem;" title="Editar"><i class="fa-solid fa-pen"></i></a>
                        <a href="#" style="color:#ef4444; font-size: 1.2rem;" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
                    </div>
                </div>
            </div>

            <div class="acta-card">
                <div class="acta-info-principal">
                    <h3>
                        <i class="fa-solid fa-file-circle-check" style="color: #10b981;"></i> 
                        Visita Extraordinaria V.E. 45/2022
                    </h3>
                    
                    <div class="acta-grid-detalles">
                        <div class="acta-detalle-item">
                            <span>Clave (Cve)</span>
                            <p>14</p>
                        </div>
                        <div class="acta-detalle-item">
                            <span>Folio</span>
                            <p>V.E. 45/2022</p>
                        </div>
                        <div class="acta-detalle-item">
                            <span>Fecha de Creación</span>
                            <p>10/05/2022</p>
                        </div>
                        <div class="acta-detalle-item" style="grid-column: span 3;">
                            <span>Inspector Asignado</span>
                            <p>VICTOR MANUEL SÁNCHEZ</p>
                        </div>
                        <div class="acta-detalle-item" style="grid-column: span 3;">
                            <span>Observaciones</span>
                            <p>Se revisaron los extintores y salidas de emergencia.</p>
                        </div>
                    </div>

                    <button class="action-button" style="background-color: transparent; border: 1px solid #334155; color: #cbd5e1; padding: 8px 15px;">
                        <i class="fa-solid fa-images"></i> Ver Evidencia Fotográfica
                    </button>
                </div>

                <div class="acta-acciones-lateral">
                    <div class="acta-status-badge status-concluido">
                        <i class="fa-solid fa-check-double" style="margin-right: 5px;"></i> CONCLUIDO
                    </div>
                    
                    <button class="action-button" style="background-color: #334155; color: white; width: 100%; justify-content: center; border: none; margin-top: 10px;">
                        <i class="fa-solid fa-file-pdf" style="margin-right: 8px; color: #ef4444;"></i> Ver PDF
                    </button>

                    <div style="display: flex; gap: 15px; margin-top: auto;">
                        <a href="#" style="color:#3b82f6; font-size: 1.2rem;" title="Editar"><i class="fa-solid fa-pen"></i></a>
                        <a href="#" style="color:#ef4444; font-size: 1.2rem;" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<script src="js/actas_scripts.js?v=<?= time() ?>"></script>

</body>
</html>