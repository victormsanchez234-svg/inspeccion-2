// --- FUNCIÓN DINÁMICA PARA TIPO DE INMUEBLE ---
function toggleCamposDinamicos() {
    var tipo = document.getElementById('tipo_inmueble').value;
    var seccionEmpresarial = document.getElementById('seccion_empresarial');
    var divGiro = document.getElementById('div_giro');

    if (!seccionEmpresarial || !divGiro) return; // Protección por si no encuentra los divs

    if (tipo === 'comercial' || tipo === 'industrial') {
        // Mostramos campos corporativos
        seccionEmpresarial.style.display = 'block';
        divGiro.style.display = 'block';
    } else if (tipo === 'residencial') {
        // Ocultamos campos corporativos para casas
        seccionEmpresarial.style.display = 'none';
        divGiro.style.display = 'none';
    } else {
        // Estado por defecto
        seccionEmpresarial.style.display = 'none';
        divGiro.style.display = 'block';
    }
}