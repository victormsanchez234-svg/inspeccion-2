// Variables globales
var miniMap = null;

// --- 1. PESTAÑAS (Listado vs Programación) ---
function switchView(viewName) {
    // Ocultamos ambas vistas
    document.getElementById('view-list').style.display = 'none';
    document.getElementById('view-schedule').style.display = 'none';
    
    // Quitamos la clase 'active' de los botones
    var tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(btn => btn.classList.remove('active'));

    if (viewName === 'list') {
        document.getElementById('view-list').style.display = 'block';
        tabs[0].classList.add('active'); // Activa el primer botón
    } else {
        document.getElementById('view-schedule').style.display = 'block';
        tabs[1].classList.add('active'); // Activa el segundo botón
    }
}

// --- 2. MODAL: AGREGAR INSPECTOR ---
function openAddModal() {
    document.getElementById('modal-add-inspector').style.display = 'flex';
}
function closeAddModal() {
    document.getElementById('modal-add-inspector').style.display = 'none';
}

// --- 3. MODAL: PERFIL DE INSPECTOR (Al hacer clic en la fila) ---
function openProfileModal(name, status) {
    // Asignamos los datos al modal
    document.getElementById('modal-name').innerText = name;
    var statusBadge = document.getElementById('modal-status');
    statusBadge.innerText = status;
    
    // Cambiamos el color del badge según el estado
    statusBadge.className = 'badge-status'; // Reset de clases
    if(status === 'Disponible') statusBadge.classList.add('status-disponible');
    else if(status === 'En Inspección') statusBadge.classList.add('status-ocupado');
    else statusBadge.classList.add('status-inactivo');

    // Mostramos el modal
    document.getElementById('modal-profile').style.display = 'flex';
    
    // Inicializamos el mapa (con un pequeño retraso para que cargue bien)
    setTimeout(function() {
        if (!miniMap) {
            // Si no existe el mapa, lo creamos
            miniMap = L.map('mini-map', {zoomControl: false}).setView([17.99, -92.94], 14);
            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { attribution: '' }).addTo(miniMap);
            L.marker([17.99, -92.94]).addTo(miniMap);
        } else {
            // Si ya existe, solo ajustamos su tamaño
            miniMap.invalidateSize();
        }
    }, 200);
}

function closeProfileModal() {
    document.getElementById('modal-profile').style.display = 'none';
}

// --- 4. MODAL: NUEVA ASIGNACIÓN ---
function openAssignModal() {
    document.getElementById('modal-assign-task').style.display = 'flex';
}

function closeAssignModal() {
    document.getElementById('modal-assign-task').style.display = 'none';
}

// --- 5. CERRAR MODALES AL DAR CLIC FUERA ---
window.onclick = function(event) {
    var modalProfile = document.getElementById('modal-profile');
    var modalAdd = document.getElementById('modal-add-inspector');
    var modalAssign = document.getElementById('modal-assign-task');
    
    if (event.target == modalProfile) closeProfileModal();
    if (event.target == modalAdd) closeAddModal();
    if (event.target == modalAssign) closeAssignModal();
}

// --- 6. FUNCIÓN PARA ELIMINAR (DAR DE BAJA) INSPECTOR ---
function eliminarInspector(id, nombre) {
    // 1. Confirmamos la acción con el usuario
    if (confirm("¿Estás seguro de que deseas dar de baja a " + nombre + "?")) {
        
        // 2. Enviamos los datos a un archivo PHP que procesará la eliminación
        // (Nota: Cambiamos la ruta del Servlet de Java por un archivo .php)
        fetch('eliminar_inspector.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id_trabajador=' + encodeURIComponent(id)
        })
        .then(response => response.text())
        .then(data => {
            if (data.trim() === 'ok') {
                alert("Inspector dado de baja correctamente.");
                location.reload(); // Recargamos para ver la tabla actualizada
            } else {
                alert("Error al eliminar: " + data);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error de conexión al intentar eliminar.");
        });
    }
}