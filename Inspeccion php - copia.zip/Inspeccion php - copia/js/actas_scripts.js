// --- 1. FUNCIONES DEL MODAL: NUEVA ACTA ---
function openNewActaModal() {
    document.getElementById('modal-new-acta').style.display = 'flex';
}
function closeNewActaModal() {
    document.getElementById('modal-new-acta').style.display = 'none';
}

// --- 2. FUNCIONES DEL MODAL: DETALLE DEL ACTA ---
// Esta función recibe los datos de la fila en la que se hizo clic
function openDetailModal(id, inmueble, fecha, inspector, estado) {
    // Llenar los campos de texto
    document.getElementById('detail-title').innerText = 'Detalles del Acta #' + id;
    document.getElementById('detail-inmueble').innerText = inmueble;
    document.getElementById('detail-fecha').innerText = fecha;
    document.getElementById('detail-inspector').innerText = inspector;
    
    // Configurar el badge grande de estado
    var statusBadge = document.getElementById('detail-status-badge');
    // Reiniciar clases para quitar colores anteriores
    statusBadge.className = 'large-status-badge'; 
    
    if(estado === 'aprobada') {
        statusBadge.innerText = 'Aprobada';
        statusBadge.classList.add('bg-bajo'); // Verde
    } else if(estado === 'reprobada') {
        statusBadge.innerText = 'Reprobada';
        statusBadge.classList.add('bg-alto'); // Rojo
    } else {
        statusBadge.innerText = 'Pendiente';
        statusBadge.classList.add('bg-pendiente'); // Amarillo
    }

    // Mostrar el modal grande
    document.getElementById('modal-detail-acta').style.display = 'flex';
}

function closeDetailModal() {
    document.getElementById('modal-detail-acta').style.display = 'none';
}

// --- 3. CERRAR MODALES AL DAR CLIC FUERA ---
window.onclick = function(event) {
    var modalNew = document.getElementById('modal-new-acta');
    var modalDetail = document.getElementById('modal-detail-acta');
    
    if (event.target == modalNew) closeNewActaModal();
    if (event.target == modalDetail) closeDetailModal();
}