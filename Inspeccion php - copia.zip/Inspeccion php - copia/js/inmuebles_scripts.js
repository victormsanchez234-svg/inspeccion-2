// Variables globales
var map = null;

// --- 1. FUNCIÓN PARA CAMBIAR VISTAS (Tabs) ---
function switchView(viewName) {
    // Ocultar ambas vistas
    var listDiv = document.getElementById('view-list');
    var mapDiv = document.getElementById('view-map');
    
    if (!listDiv || !mapDiv) return; // Protección

    listDiv.style.display = 'none';
    mapDiv.style.display = 'none';
    
    // Quitar clase 'active' a todos los botones
    var tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(function(btn) { btn.classList.remove('active'); });

    if (viewName === 'list') {
        // Mostrar Lista
        listDiv.style.display = 'block';
        if(tabs[0]) tabs[0].classList.add('active');
    } else {
        // Mostrar Mapa
        mapDiv.style.display = 'block';
        if(tabs[1]) tabs[1].classList.add('active');
        
        // EL TRUCO: Darle un micro-segundo al navegador para mostrar el div
        // antes de decirle al mapa que se recalcule.
        setTimeout(function() {
            if (!map) {
                initMapFull(); // Si no existe, lo crea
            } else {
                map.invalidateSize(); // Si ya existe, lo reajusta para que no se vea gris
            }
        }, 200); 
    }
}

// --- 2. INICIALIZAR MAPA (Villahermosa, Tabasco) ---
function initMapFull() {
    // Coordenadas centrales de Villahermosa
    map = L.map('map-full').setView([17.9892, -92.9281], 13);
    
    // Capa de mapa oscuro (Idéntico a tu captura)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { 
        attribution: '&copy; OpenStreetMap &copy; CARTO' 
    }).addTo(map);

    // Marcador 1: Riesgo Alto (Rojo)
    var marker1 = L.circleMarker([17.9950, -92.9400], { 
        color: '#ef4444', 
        fillColor: '#ef4444', 
        fillOpacity: 0.9, 
        radius: 10,
        weight: 2
    }).addTo(map);
    marker1.bindPopup("<b style='color:#0f172a;'>Plaza Las Américas</b><br><span style='color:#ef4444; font-weight:bold;'>Riesgo: Alto</span>");

    // Marcador 2: Riesgo Medio (Naranja)
    var marker2 = L.circleMarker([17.9850, -92.9200], { 
        color: '#f59e0b', 
        fillColor: '#f59e0b', 
        fillOpacity: 0.9, 
        radius: 10,
        weight: 2
    }).addTo(map);
    marker2.bindPopup("<b style='color:#0f172a;'>Escuela Benito Juárez</b><br><span style='color:#f59e0b; font-weight:bold;'>Riesgo: Medio</span>");
}

// --- 3. FUNCIONES DEL MODAL (Nuevo Inmueble) ---
function openModal() {
    var modal = document.getElementById('modal-inmueble');
    if (modal) modal.style.display = 'flex';
}

function closeModal() {
    var modal = document.getElementById('modal-inmueble');
    if (modal) modal.style.display = 'none';
}

window.onclick = function(event) {
    var modal = document.getElementById('modal-inmueble');
    if (event.target == modal) {
        closeModal();
    }
}

// --- 4. ACCIONES DE TABLA ---
function accionTabla(accion, id) {
    alert("Botón " + accion + " presionado para el ID: " + id);
}  

// --- 5. FUNCIÓN DINÁMICA PARA TIPO DE INMUEBLE ---
function toggleCamposDinamicos() {
    // Obtenemos qué opción seleccionó el usuario
    var tipo = document.getElementById('tipo_inmueble').value;
    
    // Obtenemos los bloques que vamos a ocultar o mostrar
    var seccionEmpresarial = document.getElementById('seccion_empresarial');
    var divGiro = document.getElementById('div_giro');

    if (tipo === 'comercial' || tipo === 'industrial') {
        // Si es empresa o industria: mostramos RFC, Representante y Giro
        seccionEmpresarial.style.display = 'block';
        divGiro.style.display = 'block';
        
    } else if (tipo === 'residencial') {
        // Si es una casa: no necesitamos RFC corporativo ni giro comercial
        seccionEmpresarial.style.display = 'none';
        divGiro.style.display = 'none';
        
    } else {
        // Si regresa a la opción por defecto ("-- Selecciona --")
        seccionEmpresarial.style.display = 'none';
        divGiro.style.display = 'block';
    }
}