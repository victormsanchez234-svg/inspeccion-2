<?php
// 1. INICIAR SESIÓN (Debe ser la primera línea del archivo, antes de cualquier HTML)
session_start();

if (!isset($_SESSION["cve_usuarios"])) {
    header("Location: login.php"); // Cambiado a login.php
    exit();
}

// 2. CONEXIÓN A BASE DE DATOS Y CONSULTAS
// Aquí deberías requerir tu archivo de conexión. Ejemplo:
// require_once 'conexion.php'; 
// Asumimos que tienes una variable $conn con tu conexión PDO o MySQLi

$sqlTotales = "select 
    cast(count(*) as decimal(10,0)) as total, 
    cast(sum(case when status='aprobada' then 1 else 0 end) as decimal(10,0)) as aprobadas, 
    cast(sum(case when status='reprobada' then 1 else 0 end) as decimal(10,0)) as reprobadas, 
    cast(sum(case when status='sin_acceso' then 1 else 0 end) as decimal(10,0)) as sin_acceso 
    from actas_inspeccion";

/* // EJEMPLO DE CÓDIGO PDO PARA EJECUTAR LA CONSULTA:
$stmt = $conn->query($sqlTotales);
$rsTotales = $stmt->fetch(PDO::FETCH_ASSOC);
*/

// Variables inicializadas (Reemplaza los ceros con los datos de tu BD, ej: $rsTotales['total'])
$total = 0; 
$aprobadas = 0;
$reprobadas = 0;
$sinAcceso = 0;

$sqlUltimas = "select 
    a.num_acta, 
    date_format(a.fecha,'%d/%m/%Y %H:%i') as fecha, 
    a.status, 
    i.nombre_comercial 
    from actas_inspeccion a 
    inner join inmuebles i on a.cve_inmuebles = i.cve_inmuebles 
    order by a.fecha desc 
    limit 10";

/*
// EJEMPLO DE CÓDIGO PDO PARA EJECUTAR LA CONSULTA:
$stmtUltimas = $conn->query($sqlUltimas);
$rsUltimas = $stmtUltimas->fetchAll(PDO::FETCH_ASSOC);
*/

// Arreglo vacío de prueba. Reemplazar por $rsUltimas cuando conectes tu BD.
$rsUltimas = []; 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>.: Protección Civil - Dashboard :.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="css/styles.css?v=5" rel="stylesheet" type="text/css" />
    <link href="imagenes/faviconhor.png" rel="shortcut icon" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>

<div class="dashboard-container">

    <header class="dashboard-header">
        <h1>Departamento de Inspeccion y Supervision</h1>
        <div class="header-right">
            <img src="assets/img/logo.png" alt="Logo Institución" class="top-logo">
        </div>
    </header>

    <div class="kpi-container">
        <div class="kpi-card">
            <h3>Total Inspecciones</h3>
            <span><?= $total ?></span>
        </div>
        <div class="kpi-card">
            <h3>Aprobadas</h3>
            <span><?= $aprobadas ?></span>
        </div>
        <div class="kpi-card">
            <h3>Reprobadas</h3>
            <span><?= $reprobadas ?></span>
        </div>
        <div class="kpi-card" style="border-bottom: 4px solid #ffab00 !important;">
            <h3>Sin Acceso</h3>
            <span style="color: #ffab00 !important;"><?= $sinAcceso ?></span>
        </div>
    </div>

    <div class="actions-container">
        <a href="inspecciones.php" class="action-button">Inspecciónes</a>
        <a href="inmuebles.php" class="action-button">Inmuebles</a>
        <a href="actas.php" class="action-button">Actas</a>

        <?php if (isset($_SESSION["rol"]) && $_SESSION["rol"] === "ADMIN"): ?>
            <a href="inspectores.php" class="action-button active">Inspectores</a>
        <?php endif; ?>
    </div>

    <div class="chart-section" style="margin-top: 20px; margin-bottom: 20px;">
        <div class="panel-chart" style="display: flex; flex-direction: row; align-items: center; justify-content: space-around; height: 220px; width: 100%; padding: 10px;">
            
            <div style="width: 40%; text-align: center; height: 100%;">
                <h3 style="margin: 0 0 10px 0; font-size: 1rem;">Desglose de Estatus</h3>
                <div style="height: 160px; width: 100%; position: relative;">
                    <canvas id="doughnutChart"></canvas>
                </div>
            </div>

            <div style="width: 40%; border-left: 2px solid #334155; padding-left: 20px; display: flex; flex-direction: column; justify-content: center;">
                <div style="margin-bottom: 15px;">
                    <span style="font-size: 2.5rem; font-weight: bold; color: white; line-height: 1;"><?= $total ?></span>
                    <span style="display: block; color: #94a3b8; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px;">Total Inspecciones</span>
                </div>
                
                <div style="display: flex; flex-direction: column; gap: 5px; font-size: 0.9rem; color: #cbd5e1;">
                    <div style="display: flex; align-items: center;">
                        <span class="dot green" style="width: 10px; height: 10px; border-radius: 50%; background-color: #00e676; margin-right: 8px;"></span> 
                        Aprobadas: <strong style="color: white; margin-left: 5px;"><?= $aprobadas ?></strong>
                    </div>
                    <div style="display: flex; align-items: center;">
                        <span class="dot red" style="width: 10px; height: 10px; border-radius: 50%; background-color: #ff1744; margin-right: 8px;"></span> 
                        Reprobadas: <strong style="color: white; margin-left: 5px;"><?= $reprobadas ?></strong>
                    </div>
                    <div style="display: flex; align-items: center;">
                        <span class="dot orange" style="width: 10px; height: 10px; border-radius: 50%; background-color: #ffb300; margin-right: 8px;"></span> 
                        Sin Acceso: <strong style="color: white; margin-left: 5px;"><?= $sinAcceso ?></strong>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="bottom-section">
        <div class="bottom-grid-container">

            <div class="table-section">
                <div class="section-header">
                    <h2>Últimas Inspecciones</h2>
                </div>
                <table class="data-table">
                    <tr>
                        <th>No. Acta</th>
                        <th>Inmueble</th>
                        <th>Fecha</th>
                        <th>Status</th>
                    </tr>
                    <?php if (!empty($rsUltimas)): ?>
                        <?php foreach ($rsUltimas as $fila): ?>
                            <tr>
                                <td><?= htmlspecialchars($fila["num_acta"]) ?></td>
                                <td><?= htmlspecialchars($fila["nombre_comercial"]) ?></td>
                                <td><?= htmlspecialchars($fila["fecha"]) ?></td>
                                <td><span class="badge"><?= htmlspecialchars($fila["status"]) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 20px;">No hay inspecciones registradas</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>

            <div class="actions-widget">
                <div class="widget-header">
                    <h3>Acciones</h3>
                    <span>•••</span>
                </div>
                
                <div class="map-wrapper">
                    <div id="mapa-gratis"></div>
                </div>

                <div class="activity-list">
                    <div class="activity-item">
                        <div class="dot orange"></div>
                        <div>
                            <strong>Nueva Inspección</strong><br>
                            <small>Paseo con anexo...</small>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="dot blue"></div>
                        <div>
                            <strong>Inspector Asignado</strong><br>
                            <small>Roberto G. en sector norte</small>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <script>
            var map = L.map('mapa-gratis').setView([17.9869, -92.9303], 13);
            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                attribution: '&copy; OpenStreetMap &copy; CARTO'
            }).addTo(map);
        </script>

    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=TU_API_KEY&callback=initMap" async defer></script>
  
    <div class="widget-flotante pop-in" id="panel-info">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <h3 style="margin: 0;">Info</h3>
            <button class="btn-minimize" onclick="toggleBurbuja()" title="Minimizar">
                <i class="fa-solid fa-minus"></i>
            </button>
        </div>
        
        <div class="user-info">
            Usuario: <?= htmlspecialchars($_SESSION["usuario"] ?? "Desconocido") ?> | 
            Rol: <?= htmlspecialchars($_SESSION["rol"] ?? "N/A") ?>
            <a href="logout.php" class="btn-salir">SALIR</a>
        </div>
    </div>

    <div class="burbuja-flotante pop-out" id="burbuja-info" onclick="toggleBurbuja()" style="display: none;">
        <i class="fa-solid fa-user"></i>
    </div>

</div>

<script>
    function initMap() {
        var centro = { lat: 19.4326, lng: -99.1332 }; 
        var darkStyle = [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
            { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
            { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
            { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
            { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] }
        ];

        var map = new google.maps.Map(document.getElementById("google-map"), {
            zoom: 12,
            center: centro,
            styles: darkStyle, 
            disableDefaultUI: true 
        });

        new google.maps.Marker({
            position: centro,
            map: map,
            title: "Oficina Central"
        });
    }
</script>

<script>
    // 1. CAPTURAR VARIABLES DE PHP PARA JS
    var valAprobadas = Number("<?= $aprobadas ?>");
    var valReprobadas = Number("<?= $reprobadas ?>");
    var valSinAcceso = Number("<?= $sinAcceso ?>");

    // 2. CONFIGURACIÓN DE LA GRÁFICA
    var ctx = document.getElementById('doughnutChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Aprobadas', 'Reprobadas', 'Sin Acceso'],
            datasets: [{
                data: [valAprobadas, valReprobadas, valSinAcceso],
                backgroundColor: [
                    '#00e676', // Verde Neón
                    '#ff1744', // Rojo Intenso
                    '#ffb300'  // Naranja
                ],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '75%',
            plugins: {
                legend: {
                    display: false 
                },
                tooltip: {
                    backgroundColor: 'rgba(30, 41, 59, 0.9)',
                    bodyColor: '#fff',
                    borderColor: '#334155',
                    borderWidth: 1
                }
            }
        }
    });
</script>

<script>
function toggleBurbuja() {
    const panel = document.getElementById('panel-info');
    const burbuja = document.getElementById('burbuja-info');

    if (!panel || !burbuja) {
        alert("Falta el ID 'panel-info' o 'burbuja-info' en tu HTML");
        return;
    }

    if (!panel.classList.contains('pop-out')) {
        panel.classList.remove('pop-in');
        panel.classList.add('pop-out');
        
        setTimeout(() => {
            panel.style.display = 'none';
            burbuja.style.display = 'flex';
            void burbuja.offsetWidth; 
            burbuja.classList.remove('pop-out');
            burbuja.classList.add('pop-in');
        }, 300); 
    } else {
        burbuja.classList.remove('pop-in');
        burbuja.classList.add('pop-out');
        
        setTimeout(() => {
            burbuja.style.display = 'none';
            panel.style.display = 'block'; 
            void panel.offsetWidth;
            panel.classList.remove('pop-out');
            panel.classList.add('pop-in');
        }, 300);
    }
}
</script>

</body>
</html>