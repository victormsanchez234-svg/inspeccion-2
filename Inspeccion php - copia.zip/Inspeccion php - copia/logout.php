<?php
// 1. Siempre debemos iniciar/retomar la sesión antes de poder destruirla
session_start();

// 2. Vaciamos todas las variables de sesión que existan (cve_usuarios, rol, etc.)
$_SESSION = array();

// 3. Destruimos la sesión por completo
session_destroy();

// 4. Redirigimos al usuario de vuelta a la página de login (¡ojo que ahora es .php!)
header("Location: login.php");
exit(); // Es buena práctica poner exit() después de un header para detener la ejecución
?>