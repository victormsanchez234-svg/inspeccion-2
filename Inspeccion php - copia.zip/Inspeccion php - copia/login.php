<?php
// 1. INICIAR SESIÓN (Siempre al principio)
session_start();

// Si el usuario ya está logueado, lo mandamos directo al dashboard
if (isset($_SESSION["cve_usuarios"])) {
    header("Location: dashboard.php");
    exit();
}

// 2. INICIALIZAR VARIABLES
$mensaje = "";

// 3. PROCESAR EL FORMULARIO (Se ejecuta cuando le dan clic a "INGRESAR")
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtenemos los datos del formulario de manera segura
    $usuario = $_POST['usuario'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    if (!empty($usuario) && !empty($contrasena)) {
        
        // --- AQUÍ VA TU CONEXIÓN A LA BASE DE DATOS ---
        // require_once 'conexion.php'; 
        
        // 4. LA CONSULTA SQL (Usando placeholders :usuario y :contrasena por seguridad)
        $sql = "SELECT u.cve_usuarios, t.cve_trabajadores, r.nombre as rol 
                FROM usuarios u 
                INNER JOIN trabajadores t ON u.cve_usuarios = t.cve_usuarios 
                INNER JOIN roles r ON t.cve_roles = r.cve_roles 
                WHERE u.nombre = :usuario 
                AND u.contrasena = :contrasena 
                AND t.activo = 1";

        /* // EJEMPLO DE EJECUCIÓN REAL CON PDO (Descomenta esto cuando conectes tu BD):
        $stmt = $conn->prepare($sql);
        // Vinculamos los valores para evitar Inyección SQL
        $stmt->bindParam(':usuario', $usuario);
        $stmt->bindParam(':contrasena', $contrasena);
        $stmt->execute();
        
        $rs = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($rs) { // Si las credenciales son correctas
            $_SESSION['cve_usuarios'] = (int)$rs['cve_usuarios'];
            $_SESSION['cve_trabajadores'] = (int)$rs['cve_trabajadores'];
            $_SESSION['rol'] = $rs['rol'];
            $_SESSION['usuario'] = $usuario;

            header("Location: dashboard.php");
            exit();
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }
        */

        // --- BLOQUE DE PRUEBA (Bórralo cuando uses la base de datos real) ---
        if ($usuario === 'admin' && $contrasena === '1234') {
            $_SESSION['cve_usuarios'] = 1;
            $_SESSION['cve_trabajadores'] = 1;
            $_SESSION['rol'] = 'ADMIN';
            $_SESSION['usuario'] = $usuario;
            
            header("Location: dashboard.php");
            exit();
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }
        // --------------------------------------------------------------------
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>.: Proteccion Civil - Inspeccion Acceso :.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/styles.css?v=5" rel="stylesheet" type="text/css" />
<link href="imagenes/faviconhor.png" rel="shortcut icon" type="image/png">
</head>

<body>

<div class="login-card">

  <header class="header">
    <img src="assets/img/logo.png" class="logo"  style="width: 150px; height: auto; display: block; margin: 0 auto;">
    <h1>Protección Civil</h1>
    <p>Inspeccion y Supervision</p>
  </header>

  <form action="login.php" method="post" class="login-form" autocomplete="off">

    <h2>Iniciar Sesion</h2>

    <div class="form-group">
      <label>Usuario</label>
      <input type="text" name="usuario" placeholder="Usuario" class="input-field" required>
    </div>

    <div class="form-group">
      <label>Contraseña</label>
      <input type="password" name="contrasena" placeholder="Contraseña" class="input-field" required>
    </div>

    <button type="submit" class="login-button">
      INGRESAR
    </button>

    <?php if ($mensaje !== ""): ?>
    <div class="message-box error show">
      <?= htmlspecialchars($mensaje) ?>
    </div>
    <?php endif; ?>

  </form>
</div>
</body>
</html>