<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "127.0.0.1";
$user = "root";
$pass = "root"; 
$db = "proteccion_civil_mvc";

$conn = new mysqli($host, $user, $pass, $db);

//if ($conn->connect_error) {
  //  die("<h3>¡Houston, tenemos un problema!: " . $conn->connect_error . "</h3>");
//}

//echo "<h1 style='color: green; text-align: center; margin-top: 50px;'>¡A HUEVO! La conexión fue un éxito 🥳</h1>";

return $conn;
?>