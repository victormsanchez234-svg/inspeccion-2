<?php
// Validamos la sesión antes de enviar cualquier código HTML al navegador
session_start();

if (!isset($_SESSION["cve_usuarios"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>.: Inmuebles - Protección Civil :.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="css/styles.css" rel="stylesheet" type="text/css" /> 
    <link href="imagenes/faviconhor.png" rel="shortcut icon" type="image/png">

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>

<div class="dashboard-container">

    <header class="dashboard-header">
        <h1>Gestión de Inmuebles</h1>
        <div class="header-user-info">
             <span>Usuario: <?= htmlspecialchars($_SESSION["usuario"] ?? "Desconocido") ?></span>
            <a href="dashboard.php" class="btn-salir" style="margin-left:10px;">VOLVER</a>
        </div>
    </header>

    <div class="view-tabs">
        <button class="tab-btn active" onclick="switchView('list')">Listado General</button>
        <button class="tab-btn" onclick="switchView('map')">Mapa de Riesgos</button>
    </div>

    <div id="view-list">
        
        <div class="toolbar">
            <div class="search-wrapper">
                <i class="fa-solid fa-search" style="position: absolute; left: 15px; top: 13px; color: #94a3b8;"></i>
                <input type="text" class="search-input" placeholder="Buscar por nombre, giro o dirección...">
            </div>
            
            <button onclick="window.location.href='/registro_inmuebles.php'" class="action-button" style="background-color: #ffab00; color: white; border:none; cursor: pointer;">
                + Nuevo Inmueble
            </button>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Comercial</th>
                        <th>Giro / Actividad</th>
                        <th>Dirección</th>
                        <th>Riesgo</th>
                        <th style="text-align: center;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>101</td>
                        <td><strong>Plaza Las Américas</strong></td>
                        <td>Centro Comercial</td>
                        <td>Av. Universidad #502</td>
                        <td><span class="badge-risk bg-alto">Alto</span></td>
                        <td style="text-align: center;">
                            <a href="javascript:void(0)" onclick="accionTabla('Editar', 101)" style="color:#3b82f6; margin-right:10px; font-size: 1.1rem; cursor: pointer;">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            <a href="javascript:void(0)" onclick="accionTabla('Eliminar', 101)" style="color:#ef4444; font-size: 1.1rem; cursor: pointer;">
                                <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>102</td>
                        <td><strong>Escuela Benito Juárez</strong></td>
                        <td>Educación</td>
                        <td>Calle 5 de Mayo #20</td>
                        <td><span class="badge-risk bg-medio">Medio</span></td>
                        <td style="text-align: center;">
                            <a href="javascript:void(0)" onclick="accionTabla('Editar', 102)" style="color:#3b82f6; margin-right:10px; font-size: 1.1rem; cursor: pointer;">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            <a href="javascript:void(0)" onclick="accionTabla('Eliminar', 102)" style="color:#ef4444; font-size: 1.1rem; cursor: pointer;">
                                <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div id="view-map" style="display: none;">
        <div class="panel-chart" style="width: 100%; padding: 20px; background-color: #1e293b; border-radius: 12px; border: 1px solid #334155;">
            <div id="map-full" style="width: 100%; height: 600px; border-radius: 12px; z-index: 1;"></div>
        </div>
    </div>

</div>

<script src="js/inmuebles_scripts.js?v=<?= time() ?>"></script>

</body>
</html>